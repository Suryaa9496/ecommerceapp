
import React from 'react';
import Product from './product';


export function renderProductList(products) {
  return (

    <div className="product-list">
      
      {products.map((product, index) => (
        <Product
          key={index}
          image={product.url}
          name={product.title}
          description={product.description}
          type={product.type}
          price={product.price}
          rating={product.rating}
        />
      ))}
    </div>
  );
}
