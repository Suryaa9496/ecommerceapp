const products = [
    {
      "title": "Brown eggs",
      "type": "dairy",
      "description": "Farm-fresh treasures: brown eggs, rich in flavor and nutrients.",
      "url": "https://www.kyheggs.com/image/cache/catalog/product/3-fresh-brown-eggs-large-30s-0002-800x800.jpg",
      "price": 28.1,
      "rating": 4
    },
    {
      "title": "Sweet fresh strawberry",
      "type": "fruit",
      "description": "Juicy bursts of sweetness, embodying summer's essence in each bite",
      "url": "https://images.freshop.com/2311226/af3195fa13c429464822c30de3848ed4_large.png",
      "price": 29.45,
      "rating": 4
    },
    {
      "title": "Organic milk",
      "type": "dairy",
      "description": "Pure, creamy nourishment from conscientiously cared-for cows in organic pastures",
      "url": "https://i5.walmartimages.com/asr/5897394e-5e49-4b73-b1ea-db4109b58c1b_1.3d9ff69d9fccfe4964f7d2cdac8c2097.jpeg",
      "price": 3.99,
      "rating": 5
    },
    {
      "title": "Ripe bananas",
      "type": "fruit",
      "description": "Soft, golden perfection. nature's sweet embrace in each tender bite",
      "url": "https://i5.walmartimages.com/asr/4394d565-6249-458a-9bce-2d2f3e621674_1.f1a303ce1579fe9d67dcd20a08d15b44.png?odnWidth=1000&odnHeight=1000&odnBg=ffffff",
      "price": 1.99,
      "rating": 4
    },
    {
      "title": "Whole grain bread",
      "type": "bakery",
      "description": "Nutrient-packed slices: hearty, wholesome fuel for body and soul.",
      "url": "https://i5.walmartimages.com/asr/8c0316b1-a706-4490-a211-0ffa0f7e9b64.6728851795984e734bcf8439b19064ab.jpeg?odnWidth=1000&odnHeight=1000&odnBg=ffffff",
      "price": 4.49,
      "rating": 4.5
    },
    {
      "title": "Organic tomatoes",
      "type": "vegetable",
      "description": "Sun-ripened, vibrant orbs bursting with organic garden goodness",
      "url": "https://images.freshop.com/1564405684711691370/937017e06af7dc57b04b682a036f8004_large.png",
      "price": 2.99,
      "rating": 4.2
    },
   ,
    {
      "title": "Fresh carrots",
      "type": "vegetable",
      "description": "Vibrant roots: nature's crisp, nutrient-packed bites of orange goodness",
      "url": "https://tse4.mm.bing.net/th/id/OIP.pA7lZfBMi4r815uSwPKCegAAAA?w=450&h=450&rs=1&pid=ImgDetMain",
      "price": 1.49,
      "rating": 4.3
    },
 
    {
      "title": "Honeycrisp apples",
      "type": "fruit",
      "description": "Juicy, crisp delight: Honeycrisp apples offer a burst of sweet refreshment.",
      "url": "https://images.heb.com/is/image/HEBGrocery/000466634",
      "price": 3.29,
      "rating": 4.6
    },
    {
      "title": "Extra virgin olive oil",
      "type": "pantry",
      "description": "Pure liquid gold: virgin olive oil, essence of Mediterranean splendor.",
      "url": "https://i5.walmartimages.com/asr/b31a9274-be15-42ca-9022-6f623c5ea03d_2.d0c0b2991030a31e18ad42de872ee47b.jpeg",
      "price": 9.99,
      "rating": 4.9
    },
    {
      "title": "Fresh salmon fillet",
      "type": "seafood",
      "description": "Buttery, pink perfection: salmon fillet, a gourmet delight from sea",
      "url": "https://tse4.mm.bing.net/th/id/OIP.xlbYR-d7cwN7U_3kbFnEoAHaHa?rs=1&pid=ImgDetMain",
      "price": 16.99,
      "rating": 4.7
    },
    {
      "title": "Organic spinach",
      "type": "vegetable",
      "description": "Lush green leaves: organic spinach, packed with nutrients and vitality",
      "url": "https://th.bing.com/th/id/R.d38d0c31b25b886c51c5794e2f3f0c1c?rik=NEa7qMRjsDeJFA&riu=http%3a%2f%2fseed2plant.in%2fcdn%2fshop%2fproducts%2fspinachseeds.jpg%3fv%3d1603966262&ehk=%2fGeQPfQ7pPl60qZsxiBzP48WqN3LOnKPZ0kHmJRAgCw%3d&risl=&pid=ImgRaw&r=0",
      "price": 2.49,
      "rating": 4.5
    },
    {
      "title": "Whole grain pasta",
      "type": "pantry",
      "description": "Nutrient-rich strands: whole grain pasta, a wholesome delight in every twirl.",
      "url": "https://tse4.mm.bing.net/th/id/OIP.BxFWEIYDrXdrvmdl6MQKUQHaKv?rs=1&pid=ImgDetMain",
      "price": 3.79,
      "rating": 4.4
    },
    {
      "title": "Fair-trade coffee beans",
      "type": "beverage",
      "description": "Bold aroma, rich flavor: fresh trade coffee beans, a morning necessity.",
      "url": "https://tse2.mm.bing.net/th/id/OIP.a5EIHjPfPTmS1XjNCBdrZgHaHa?rs=1&pid=ImgDetMain",
      "price": 8.49,
      "rating": 4.6
    },
    {
      "title": "Artisanal cheese",
      "type": "dairy",
      "description": "Handcrafted perfection: A symphony of flavor and texture.",
      "url": "https://www.calendarcheese.com.au/wp-content/uploads/2018/10/704227-768x620.jpg",
      "price": 7.99,
      "rating": 4.8
    },
    {
      "title": "Fresh  orange juice",
      "type": "beverage",
      "description": "Zesty sunshine in a bottle: fresh orange juice, nature's morning elixir.",
      "url": "https://tse1.mm.bing.net/th/id/OIP.6_GAyV7l49RXUxPJOalzlQHaHa?rs=1&pid=ImgDetMain",
      "price": 4.29,
      "rating": 4.3
    }
  

  ];
  
  export default products;
  