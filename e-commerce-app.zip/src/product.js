import React, { useState } from 'react';

const Product = ({ image, name, description, type, price, rating }) => {
  const [showDescription, setShowDescription] = useState(false);

  const toggleDescription = () => {
    setShowDescription(!showDescription);
  };

  const handlePurchase = () => {
    alert(`You purchased ${name}`);
  };

 

  const handleShare = () => {
    alert(`You copied ${name} link`);
  };

  return (
    <div className="product">
      <img className="img" src={image} alt={name} />
      <h2>{name}</h2>
      {showDescription && <p>{description}</p>}
      <p>Type: {type}</p>
      <p>Price: ${price}</p>
      <p>Rating: {rating}</p>

      <button className="descrip" onClick={toggleDescription}>
        {showDescription ? 'Hide Description' : 'View Description'}
      </button>
      <br></br>
      <button className='btn' onClick={handlePurchase}>Purchase</button>

      <div className='icons'>
        <label class="container">
          <input type="checkbox" />
          <svg id="Glyph" version="1.1" viewBox="0 0 32 32" space="preserve" xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" >
            <path d="M29.845,17.099l-2.489,8.725C26.989,27.105,25.804,28,24.473,28H11c-0.553,0-1-0.448-1-1V13c0-0.215,0.069-0.425,0.198-0.597l5.392-7.24C16.188,4.414,17.05,4,17.974,4C19.643,4,21,5.357,21,7.026V12h5.002c1.265,0,2.427,0.579,3.188,1.589C29.954,14.601,30.192,15.88,29.845,17.099z" id="XMLID_254_"></path>
            <path d="M7,12H3c-0.553,0-1,0.448-1,1v14c0,0.552,0.447,1,1,1h4c0.553,0,1-0.448,1-1V13C8,12.448,7.553,12,7,12z M5,25.5c-0.828,0-1.5-0.672-1.5-1.5c0-0.828,0.672-1.5,1.5-1.5c0.828,0,1.5,0.672,1.5,1.5C6.5,24.828,5.828,25.5,5,25.5z" id="XMLID_256_"></path>
          </svg>
        </label>

        <button class='share' onClick={handleShare}><img class='btn-img' src='https://cdn1.iconfinder.com/data/icons/modern-universal/32/icon-29-1024.png' alt='share'></img></button>
      </div>
    </div>
  );
};

export default Product;
