import React from 'react';
import './App.css';
import { renderProductList } from './productfunction';
import products from './productdetails'; 

function App() {
  return (
    <div className="App">
      <h1>Products</h1>
      {renderProductList(products)}
    </div>
  );
}

export default App;
